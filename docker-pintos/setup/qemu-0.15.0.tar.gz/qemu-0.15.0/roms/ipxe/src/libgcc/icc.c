/*
 * Intel's compiler creates an implicit call to this function at the
 * start of main().
 *
 */
void __libgcc __intel_new_proc_init ( void ) {
	/* Do nothing */
}
